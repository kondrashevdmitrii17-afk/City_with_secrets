@echo off
python City.py
pause